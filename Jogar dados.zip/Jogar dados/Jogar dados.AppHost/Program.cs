var builder = DistributedApplication.CreateBuilder(args);

var apiService = builder.AddProject<Projects.Jogar_dados_ApiService>("apiservice");

builder.AddProject<Projects.Jogar_dados_Web>("webfrontend")
    .WithExternalHttpEndpoints()
    .WithReference(apiService)
    .WaitFor(apiService);

builder.Build().Run();
