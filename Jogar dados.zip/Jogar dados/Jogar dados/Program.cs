﻿Console.WriteLine("Bem vindo ao jogo de dados!\n");
Console.WriteLine("Digite o nome do primeiro jogador!\n");

int confirmaçãoJogadores = 0;


Random numeroAleatorioDado = new Random();

string nomeJogador1 = "";
string nomeJogador2 = "";

int[] numerosJogador1;
int[] numerosJogador2;

int irPraRodadaExtra = 0;

while (confirmaçãoJogadores < 1)
{
    string primeiroPlayer = Console.ReadLine();
    Console.WriteLine("");

    while (primeiroPlayer == "" || primeiroPlayer.Length < 4)
    {
        Console.WriteLine("Poderia digitar outro nome?\n");
        primeiroPlayer = Console.ReadLine();
        Console.WriteLine("");
    }

    confirmaçãoJogadores++;

    Console.WriteLine("Obrigado!\n");

    nomeJogador1 = primeiroPlayer;


    Console.WriteLine("Digite o nome do segundo jogador!\n");

    while (confirmaçãoJogadores < 2)
    {
        string segundoPlayer = Console.ReadLine();
        Console.WriteLine("");

        while (segundoPlayer == "" || segundoPlayer.Length < 4)
        {
            Console.WriteLine("Podereia digitar outro nome?\n");
            segundoPlayer = Console.ReadLine();
            Console.WriteLine("");
        }

            nomeJogador2 = segundoPlayer;

            while (nomeJogador1.Equals(nomeJogador2))
            {
            Console.WriteLine("Por favor, não use nomes iguais, troque agora\n");
            string trocaNome = Console.ReadLine();
            Console.WriteLine("");

            nomeJogador2 = trocaNome;
            }

        confirmaçãoJogadores++;
        Console.WriteLine("Obrigado! Vamos começar agora.\n");
    }
}

Console.WriteLine("Por favor, agora me dê a quantidade de rodadas que você quer jogar o jogo com o amiguinho!");

string rodadaFinal = Console.ReadLine();

int rodadaFinalConvertida;
rodadaFinalConvertida = Convert.ToInt32(rodadaFinal);

int confirmaçãoRodada = 0;
int confirmaçãoTrocaNumeroRodada = 0;

while (confirmaçãoRodada != 1)
{
    switch (rodadaFinal)
    {
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
            confirmaçãoRodada++;
            break;

        default:
            while (confirmaçãoTrocaNumeroRodada != 1)
            {
                Console.WriteLine("Número inválido, escolha outro\n");
                rodadaFinal= Console.ReadLine();

                if (rodadaFinal == "1" || rodadaFinal == "2" || rodadaFinal == "3" || rodadaFinal == "4" || rodadaFinal == "5")
                {
                    confirmaçãoTrocaNumeroRodada++;
                    confirmaçãoRodada++;
                    rodadaFinalConvertida = Convert.ToInt32(rodadaFinal);

                    Console.WriteLine($"\nObrigado, o número de rodadas escolhidas foi: {rodadaFinal}\n");
                }
            }
            break;
    }
}


Console.WriteLine("Para ver as rodadas indo 1 por 1 clique espaço para continuar.");
string passar = Console.ReadLine();
if (passar == "")
{
    Console.Write("\n");
}


int pontuaçãoJ1 = 0;
int pontuaçãoJ2 = 0;

int RodadaAMais = 0;

for (int rodada = 0; rodada <= rodadaFinalConvertida; rodada++)
{
    numerosJogador1 = new int[rodadaFinalConvertida];
    numerosJogador2 = new int[rodadaFinalConvertida];

    numerosJogador1[rodada] = numeroAleatorioDado.Next(1, 6);
    numerosJogador2[rodada] = numeroAleatorioDado.Next(1, 6);

    Console.Write($"{rodada+1}º rodada:\n");
    Console.WriteLine($"{nomeJogador1} tirou: {numerosJogador1[rodada]} \n{nomeJogador2} tirou: {numerosJogador2[rodada]}");

    if (numerosJogador1[rodada] > numerosJogador2[rodada])
    {
        pontuaçãoJ1++;
        Console.WriteLine($"{nomeJogador1} ganhou essa rodada!\nPontuação: \n{nomeJogador1}: {pontuaçãoJ1}\n{nomeJogador2}: {pontuaçãoJ2}");
    }
    else if (numerosJogador1[rodada] < numerosJogador2[rodada])
    {
        pontuaçãoJ2++;
        Console.Write($"{nomeJogador2} ganhou essa rodada!\nPontuação: \n{nomeJogador1}: {pontuaçãoJ1}\n{nomeJogador2}: {pontuaçãoJ2}");
    }
    else
    {
        Console.WriteLine($"Deu empate, ninguêm ganha ponto... \n{nomeJogador1}: {pontuaçãoJ1}\n{nomeJogador2}: {pontuaçãoJ2}");
    }

    Console.WriteLine("\nPróxima rodada! (Clique espaço)");
    string PróximaRodada = Console.ReadLine();
    if (PróximaRodada == "")
    {
        irPraRodadaExtra++;
        Console.Write("\n");
    }

    while (irPraRodadaExtra == rodadaFinalConvertida)
    {
       if (pontuaçãoJ1 > pontuaçãoJ2)
        {
            Console.WriteLine($"O(A) {nomeJogador1} ganhou o jogo com {pontuaçãoJ1} pontos!");
            return;
        }
       else if (pontuaçãoJ1 < pontuaçãoJ2)
        {
            Console.WriteLine($"O(A) {nomeJogador2} ganhou o jogo com {pontuaçãoJ2} pontos!");
            return;
        }
       else
        {
            while (RodadaAMais != 1)
            {
                Console.WriteLine($"A pontuação de ambos foi de {pontuaçãoJ2}, Gostaria de ter uma próxima rodada?\n");
                string RodadaExtra = Console.ReadLine();

                if (RodadaExtra == "Não" || RodadaExtra == "não")
                {
                    Console.WriteLine("Ok, acabou!");
                    return;
                }
                else if (RodadaExtra == "Sim" || RodadaExtra == "sim"){
                    rodadaFinalConvertida++;
                    RodadaAMais++;
                } 
            }
            Console.WriteLine($"Deu empate de novo, que má sorte.\n Fim de jogo.\n{nomeJogador1}: {pontuaçãoJ1}\n{nomeJogador2}: {pontuaçãoJ2}");
            return;
        }
    }
}


